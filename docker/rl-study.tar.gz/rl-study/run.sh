#!/usr/bin/env bash
set -euo pipefail

# Use,like: ./run.sh [cpu|cu118|cu121...] [workspace_host_dir]
# example:
#   ./run.sh cu118
#   ./run.sh cpu ./workspace_cpu
COMPUTE="${1:-cu118}"
WORKSPACE_HOST="${2:-$PWD/workspace}"

IMAGE="rl-study:${COMPUTE}"
NAME="rl-study-${COMPUTE}"

# Ports
JUPYTER_PORT_HOST=19999
TBOARD_PORT_HOST=19991

# X11 Settings
DISPLAY_ENV="${DISPLAY:-}"
XSOCK="/tmp/.X11-unix"
XOPTS=()
if [[ -n "${DISPLAY_ENV}" && -d "${XSOCK}" ]]; then
  command -v xhost >/dev/null 2>&1 && xhost +local:docker >/dev/null 2>&1 || true
  XOPTS+=( -e "DISPLAY=${DISPLAY_ENV}" -v "${XSOCK}:${XSOCK}:ro" )
fi

# ws dir
mkdir -p "${WORKSPACE_HOST}"

# GPU/CPU?
RUNCMD=( docker run -it --rm --name "${NAME}" )
if [[ "${COMPUTE}" == "cpu" ]]; then
  # CPU: no --gpus option at all, OSMesa-renderer
  MUJOCO_GL="osmesa"
else
  # GPU: --gpus all ok, EGL-renderer
  MUJOCO_GL="egl"
  RUNCMD+=( --gpus all )
fi

# RUN!
RUNCMD+=(
  -p "${JUPYTER_PORT_HOST}:19999"    # Jupyter
  -p "${TBOARD_PORT_HOST}:19991"     # TensorBoard
  -e "MUJOCO_GL=${MUJOCO_GL}"
  "${XOPTS[@]}"
  -v "${WORKSPACE_HOST}:/home/rl/workspace"
  "${IMAGE}"
)

echo ">>> Running container: ${NAME}"
echo ">>> Image: ${IMAGE}"
echo ">>> Workspace(host): ${WORKSPACE_HOST}"
echo ">>> Jupyter:    http://localhost:${JUPYTER_PORT_HOST}   (pass: seerl2study)"
echo ">>> TensorBoard: http://localhost:${TBOARD_PORT_HOST}"
echo ">>> MUJOCO_GL=${MUJOCO_GL}"
echo ">>> Starting now..."
"${RUNCMD[@]}"
