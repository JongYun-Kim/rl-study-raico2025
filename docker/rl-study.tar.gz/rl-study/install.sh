#!/usr/bin/env bash
set -euo pipefail

# Use-like: ./install.sh [cpu|cu118|cu121...]
# default: cu118
COMPUTE="${1:-cu118}"

IMAGE="rl-study:${COMPUTE}"

echo ">>> Building Docker image: ${IMAGE}"
echo ">>> COMPUTE=${COMPUTE}  (cpu -> CPU 전용 휠, cu118 -> CUDA 11.8 휠)"

# Use current host's user's UID/GID help you to use the files from the container on the host machine
UID_ARG="$(id -u)"
GID_ARG="$(id -g)"

docker build \
  --build-arg COMPUTE="${COMPUTE}" \
  --build-arg UID="${UID_ARG}" \
  --build-arg GID="${GID_ARG}" \
  -t "${IMAGE}" .

echo ">>> Done. Built image: ${IMAGE}"
