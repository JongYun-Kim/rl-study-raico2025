#!/usr/bin/env bash
set -euo pipefail

# Usage: ./run.sh [cpu|cu118|cu121...] [workspace_host_dir]
# Examples:
#   ./run.sh cu118
#   ./run.sh cpu ./workspace_cpu

COMPUTE="${1:-cu118}"
WORKSPACE_HOST="${2:-$PWD/workspace}"

IMAGE="rl-study:${COMPUTE}"
NAME="rl-study-${COMPUTE}"

# Ports
JUPYTER_PORT_HOST=19999
TBOARD_PORT_HOST=19991

# Detect host system
UNAME_S="$(uname -s || true)"
UNAME_M="$(uname -m || true)"

# -------------------------------
# Apple Silicon handling
# -------------------------------
APPLE_SILICON=false
if [[ "${UNAME_S}" == "Darwin" && "${UNAME_M}" == "arm64" ]]; then
  APPLE_SILICON=true
  if [[ "${COMPUTE}" != "cpu" ]]; then
    echo ">>> Apple Silicon detected (Darwin/arm64)"
    echo ">>> CUDA not supported; overriding COMPUTE=${COMPUTE} -> cpu"
    COMPUTE="cpu"
    IMAGE="rl-study:cpu"
    NAME="rl-study-cpu"
  fi
fi

# -------------------------------
# X11 Settings
# - Apple Silicon: use TCP X11 via XQuartz (host.docker.internal:0)
# - Others: use Unix socket passthrough (/tmp/.X11-unix) if available
# -------------------------------
XOPTS=()
if $APPLE_SILICON; then
  # TCP display to XQuartz (Enable in XQuartz: Preferences > Security > "Allow connections from network clients")
  # Also run once on host:  xhost +127.0.0.1  (or temporarily `xhost +` if testing)
  XOPTS+=( -e "DISPLAY=host.docker.internal:0" )
else
  DISPLAY_ENV="${DISPLAY:-}"
  XSOCK="/tmp/.X11-unix"
  if [[ -n "${DISPLAY_ENV}" && -d "${XSOCK}" ]]; then
    if command -v xhost >/dev/null 2>&1; then
      xhost +local:docker >/dev/null 2>&1 || true
    fi
    XOPTS+=( -e "DISPLAY=${DISPLAY_ENV}" -v "${XSOCK}:${XSOCK}:ro" )
  fi
fi

# -------------------------------
# Workspace directory
# -------------------------------
mkdir -p "${WORKSPACE_HOST}"

# -------------------------------
# Build base docker run command
# -------------------------------
RUNCMD=( docker run -it --rm --name "${NAME}" )

# CPU/GPU switch
if [[ "${COMPUTE}" == "cpu" ]]; then
  MUJOCO_GL="osmesa"
else
  MUJOCO_GL="egl"
  RUNCMD+=( --gpus all )
fi

# -------------------------------
# Mount workspace and set user
# -------------------------------
UID_ARG="$(id -u)"
GID_ARG="$(id -g)"

RUNCMD+=(
  -u "${UID_ARG}:${GID_ARG}"               # keep file ownership consistent
  -p "${JUPYTER_PORT_HOST}:19999"          # Jupyter
  -p "${TBOARD_PORT_HOST}:19991"           # TensorBoard
  -e "MUJOCO_GL=${MUJOCO_GL}"
  "${XOPTS[@]}"
  -v "${WORKSPACE_HOST}:/home/rl/workspace"
  "${IMAGE}"
)

# -------------------------------
# Launch
# -------------------------------
echo ">>> Running container: ${NAME}"
echo ">>> Image: ${IMAGE}"
echo ">>> Workspace(host): ${WORKSPACE_HOST}"
echo ">>> Jupyter:     http://localhost:${JUPYTER_PORT_HOST}   (pass: seerl2study)"
echo ">>> TensorBoard: http://localhost:${TBOARD_PORT_HOST}"
echo ">>> MUJOCO_GL=${MUJOCO_GL}"
echo ">>> UID:GID=${UID_ARG}:${GID_ARG}"

if $APPLE_SILICON; then
  echo ">>> Apple Silicon mode: DISPLAY=host.docker.internal:0 (XQuartz TCP)"
  echo ">>> Make sure XQuartz: Preferences > Security > 'Allow connections from network clients' is enabled"
  echo ">>> And on host: xhost +127.0.0.1"
else
  if [[ -n "${DISPLAY:-}" ]]; then
    echo ">>> DISPLAY propagated from host: ${DISPLAY}"
  else
    echo ">>> No DISPLAY detected on host; X11 apps may not show."
  fi
fi

echo ">>> Starting now..."
"${RUNCMD[@]}"