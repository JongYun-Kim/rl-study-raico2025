#!/usr/bin/env bash
set -euo pipefail

# Use-like: ./install.sh [cpu|cu118|cu121...]
# default: cu118  (Linux x86_64 환경에서의 기본값 유지)
REQ_COMPUTE="${1:-cu118}"

IMAGE="rl-study:${REQ_COMPUTE}"

echo ">>> Requested COMPUTE=${REQ_COMPUTE}  (cpu -> CPU-only wheels, cu118 -> CUDA 11.8 wheels)"

# Host IDs for file permission matching
UID_ARG="$(id -u)"
GID_ARG="$(id -g)"

# Detect platform
UNAME_S="$(uname -s || true)"
UNAME_M="$(uname -m || true)"

PLATFORM_FLAG=""
COMPUTE="${REQ_COMPUTE}"

if [[ "${UNAME_S}" == "Darwin" && "${UNAME_M}" == "arm64" ]]; then
  echo ">>> Detected Apple Silicon (Darwin/arm64). Forcing platform linux/arm64."
  PLATFORM_FLAG="--platform linux/arm64"

  # CUDA 불가 → cpu로 강제 전환
  if [[ "${REQ_COMPUTE}" != "cpu" ]]; then
    echo "!!! CUDA is not supported on Apple Silicon Linux/arm64 containers. Overriding COMPUTE=${REQ_COMPUTE} -> cpu"
    COMPUTE="cpu"
    IMAGE="rl-study:cpu"
  fi
fi

echo ">>> Building Docker image: ${IMAGE}"
echo ">>> Final COMPUTE=${COMPUTE}"
echo ">>> UID=${UID_ARG} GID=${GID_ARG}"
echo ">>> PLATFORM_FLAG='${PLATFORM_FLAG}'"

# Build
docker build ${PLATFORM_FLAG} \
  --build-arg COMPUTE="${COMPUTE}" \
  --build-arg UID="${UID_ARG}" \
  --build-arg GID="${GID_ARG}" \
  -t "${IMAGE}" .

echo ">>> Done. Built image: ${IMAGE}"